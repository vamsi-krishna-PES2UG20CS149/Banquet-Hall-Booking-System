# Banquet-Booking-System
How to run the Online Banquet Booking System Project using PHP and MySQL

1. Download the project zip file

2. Extract the file and copy obbs folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/Html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name  obbs

6. Import obbs.sql file(given inside the zip package in SQL file folder)

7. Run the script http://localhost/obbs1



Credential for User panel :
Username: jd@gmail.com
Password: password@123
Or Register a new user.
