    
    <!-- copyright -->
    <div class="agileits-w3layouts">
        <div class="container">
            <p>© 2022 Online Banquet Booking System. All rights reserved | </p>
        </div>
    </div>
    <!-- //copyright -->